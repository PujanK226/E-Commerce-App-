import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'login.dart';
// ignore: unused_import
import 'package:url_launcher/url_launcher.dart';
// ignore: duplicate_import
import 'package:flutter/gestures.dart';

// ignore: camel_case_types
class registerScreen extends StatefulWidget {
  static const routeName = '/register';
  @override
  _registerScreenState createState() => _registerScreenState();
}

// ignore: camel_case_types
class _registerScreenState extends State<registerScreen> {
  final GlobalKey<FormState> _formkey = GlobalKey();
  TextEditingController _passwordController = new TextEditingController();
  void _submit() {}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register'),
        actions: <Widget>[
          // ignore: missing_required_param
          // ignore: deprecated_member_use
          FlatButton(
            child: Row(
              children: <Widget>[Text('Login'), Icon(Icons.person)],
            ),
            textColor: Colors.white,
            onPressed: () {
              Navigator.of(context).pushReplacementNamed(loginScreen.routeName);
            },
          )
        ],
      ),
      body: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
              Colors.red,
              Colors.red,
            ])),
          ),
          Center(
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                height: 430,
                width: 300,
                padding: EdgeInsets.all(16),
                child: Form(
                  key: _formkey,
                  child: SingleChildScrollView(
                    child: Column(
                      children: <Widget>[
                        // for full name
                        TextFormField(
                          decoration: InputDecoration(labelText: 'Full Name'),
                          keyboardType: TextInputType.name,
                          validator: (value) {
                            if (value.isEmpty) {
                              return 'You cannot leave the box empty';
                            }
                            return null;
                          },
                          onSaved: (value) {},
                        ),

                        //for phone number
                        TextFormField(
                          decoration:
                              InputDecoration(labelText: 'Phone Number'),
                          keyboardType: TextInputType.number,
                          validator: (value) {
                            if (value.isEmpty || value.length <= 10) {
                              return 'You cannot leave the box empty';
                            }
                            return null;
                          },
                          onSaved: (value) {},
                        ),

                        //for input type email
                        TextFormField(
                          decoration: InputDecoration(labelText: 'Email Id'),
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value.isEmpty || !value.contains('@')) {
                              return 'not a valid email';
                            }
                            return null;
                          },
                          onSaved: (value) {},
                        ),

                        //for password
                        TextFormField(
                          decoration: InputDecoration(labelText: 'Password'),
                          obscureText: true,
                          // controller: ,
                          validator: (value) {
                            if (value.isEmpty) {
                              return 'empty value';
                            } else if (value.length <= 8) {
                              return 'Please enter at least 8 digit password';
                            }
                            return null;
                          },
                          onSaved: (value) {},
                        ),
                        SizedBox(
                          height: 30,
                        ),

                        // for re type
                        TextFormField(
                          decoration:
                              InputDecoration(labelText: 'Re-enter Password'),
                          obscureText: true,
                          validator: (value) {
                            if (value.isEmpty) {
                              return 'empty value';
                            } else if (value != _passwordController.text) {
                              return 'Please enter at least 8 digit password';
                            }
                            return null;
                          },
                          onSaved: (value) {},
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        // ignore: deprecated_member_use
                        RaisedButton(
                          child: Text('Register'),
                          onPressed: () {
                            _submit();
                          },
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          color: Colors.red,
                          textColor: Colors.black,
                        ),
                        Text("\n\n"),
                        Text("      or continue with:"),
                        Text('________________________________________'),
                        SizedBox(
                          height: 30,
                          width: 60,
                        ),

                        // ignore: deprecated_member_use
                        RaisedButton(
                          child: Text('Facebook'),

                          // ignore: missing_required_param

                          recognizer: TapGestureRecognizer()
                            ..onTap = () async {
                              // ignore: unused_local_variable
                              var url = 'https://www.facebook.com/';
                            },
                          onPressed: () {
                            _submit();
                            // ignore: unused_label
                          },
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          color: Colors.blue,
                          textColor: Colors.white,
                        ),
                        // ignore: deprecated_member_use
                        RaisedButton(
                          child: Text('Google'),
                          onPressed: () {
                            _submit();
                            // ignore: unused_label
                          },
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          color: Colors.red,
                          textColor: Colors.white,
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
